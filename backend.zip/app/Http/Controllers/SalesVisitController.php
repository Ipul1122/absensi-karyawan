<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SalesVisit;
use App\Models\Attendance;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class SalesVisitController extends Controller
{
    /**
     * Store a new sales visit log.
     */
    public function store(Request $request)
    {
        $request->validate([
            'client_name' => 'required|string|max:255',
            'latitude' => 'required|string',
            'longitude' => 'required|string',
            'photo' => 'required|string', // base64 string
            'notes' => 'nullable|string',
            'visit_type' => 'nullable|string|in:sales,client',
        ]);

        $user = $request->user();
        $today = Carbon::today()->toDateString();
        $visitType = $request->input('visit_type', 'sales');

        try {
            // Save photo
            $photoPath = $this->saveBase64Image($request->photo, 'visit_' . $user->id);

            // Create record
            $visit = SalesVisit::create([
                'user_id' => $user->id,
                'date' => $today,
                'visit_time' => Carbon::now()->format('H:i:s'),
                'client_name' => $request->client_name,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'photo_path' => $photoPath,
                'notes' => $request->notes,
                'visit_type' => $visitType,
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Kunjungan berhasil dilaporkan!',
                'data' => $visit
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Gagal memproses laporan kunjungan: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get employee's logged visits for today.
     */
    public function getTodayVisits(Request $request)
    {
        $userId = $request->user()->id;
        $today = Carbon::today()->toDateString();

        $query = SalesVisit::where('user_id', $userId)
            ->whereDate('date', $today);

        // Filter berdasarkan visit_type jika diberikan (sales atau client)
        if ($request->has('visit_type') && in_array($request->visit_type, ['sales', 'client'])) {
            $query->where('visit_type', $request->visit_type);
        }

        $visits = $query->orderBy('visit_time', 'asc')->get();

        return response()->json([
            'status' => 'success',
            'data' => $visits
        ]);
    }

    /**
     * Get all sales visits for admin.
     */
    public function getAllVisits(Request $request)
    {
        $query = SalesVisit::with('user:id,name,email,photo');

        if ($request->has('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        if ($request->has('date')) {
            $query->whereDate('date', $request->date);
        }

        $visits = $query->orderBy('date', 'desc')
            ->orderBy('visit_time', 'desc')
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $visits
        ]);
    }

    /**
     * Helper to decode and save base64 image.
     */
    private function saveBase64Image($base64String, $prefix)
    {
        if (preg_match('/^data:image\/(\w+);base64,/', $base64String, $type)) {
            $imageData = substr($base64String, strpos($base64String, ',') + 1);
            $type = strtolower($type[1]); // jpg, png, etc.

            if (!in_array($type, ['jpg', 'jpeg', 'gif', 'png', 'webp'])) {
                throw new \Exception('Tipe gambar tidak valid.');
            }

            $imageBytes = base64_decode($imageData);

            if ($imageBytes === false) {
                throw new \Exception('Gagal mendecode base64.');
            }
        } else {
            throw new \Exception('Format data URI gambar tidak sesuai.');
        }

        // Tentukan ekstensi dan nama file default (webp jika menggunakan kompresi)
        $useWebp = extension_loaded('gd');
        $extension = $useWebp ? 'webp' : $type;
        $fileName = $prefix . '_' . time() . '_' . uniqid() . '.' . $extension;
        $filePath = 'visits/' . $fileName;

        // Ensure directories exist
        Storage::disk('public')->makeDirectory('visits');

        if ($useWebp) {
            try {
                // Buat GD image object dari raw bytes
                $srcImage = imagecreatefromstring($imageBytes);
                if ($srcImage !== false) {
                    $origWidth = imagesx($srcImage);
                    $origHeight = imagesy($srcImage);

                    // Tentukan ukuran baru (maksimal lebar 800px)
                    $maxWidth = 800;
                    $webpData = false;

                    if ($origWidth > $maxWidth) {
                        $newWidth = $maxWidth;
                        $newHeight = (int) (($origHeight / $origWidth) * $maxWidth);

                        // Buat canvas baru
                        $dstImage = imagecreatetruecolor($newWidth, $newHeight);

                        // Tangani transparansi untuk PNG/GIF
                        imagealphablending($dstImage, false);
                        imagesavealpha($dstImage, true);
                        
                        // Lakukan resize
                        imagecopyresampled($dstImage, $srcImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);
                        
                        // Siapkan output buffer untuk menangkap raw webp bytes
                        ob_start();
                        imagewebp($dstImage, null, 75); // kualitas 75%
                        $webpData = ob_get_clean();

                        imagedestroy($dstImage);
                    } else {
                        // Tidak perlu resize, langsung kompres ke WebP
                        ob_start();
                        imagewebp($srcImage, null, 75);
                        $webpData = ob_get_clean();
                    }

                    imagedestroy($srcImage);

                    if ($webpData !== false) {
                        $imageBytes = $webpData;
                    }
                }
            } catch (\Throwable $e) {
                // Fallback ke data asli jika ada error pemrosesan GD
            }
        }

        Storage::disk('public')->put($filePath, $imageBytes);

        return '/storage/' . $filePath;
    }
}
